<?php
/*
�*�Created�on�13/09/2009
�*/
$ip = $_SERVER['REMOTE_ADDR'];
$nomeImagem = 'imagem/' . $ip . '.jpg';

if ($setaArquivo = fopen($nomeImagem, 'w'))
{
    fwrite($setaArquivo, base64_decode( $_POST['IMG']));
    echo $nomeImagem;
}
else
{
    echo "erro";
}
?>